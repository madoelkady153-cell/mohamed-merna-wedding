// دفتر التهاني - Google Apps Script
// الصق الكود ده في Extensions > Apps Script جوه Google Sheet فاضي.

function doPost(e) {
  var d = JSON.parse(e.postData.contents);
  var n = clean_(d.n, 60), m = clean_(d.m, 500);
  if (!n || !m) return ContentService.createTextOutput('missing');
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];
  if (sh.getLastRow() === 0) sh.appendRow(['Time', 'Name', 'Message']);
  sh.appendRow([new Date(), n, m]);
  return ContentService.createTextOutput('ok');
}

function doGet() {
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];
  var rows = sh.getLastRow() > 1 ? sh.getRange(2, 1, sh.getLastRow() - 1, 3).getValues() : [];
  var wishes = rows.map(function (r) { return { n: String(r[1]), m: String(r[2]) }; });
  return ContentService.createTextOutput(JSON.stringify({ wishes: wishes }))
    .setMimeType(ContentService.MimeType.JSON);
}

function clean_(v, max) {
  v = String(v || '').trim().slice(0, max);
  if (/^[=+\-@]/.test(v)) v = "'" + v; // يمنع تنفيذ معادلات داخل الشيت
  return v;
}
